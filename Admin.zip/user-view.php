<?php
require_once("functions/function.php");
NeedLogged();
get_header();
get_sidebar();
get_breadcam();
?>
<div class="col-md-12">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <div class="col-md-9 heading_title">
                Personal Information
            </div>
            <div class="col-md-3 text-right">
                <a href="user-data.php" class="btn btn-sm btn btn-primary"><i class="fa fa-plus-circle"></i> All User List</a>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="panel-body">
            <div class="col-md-1">
            </div>
            <div class="col-md-9">
                <table class="table table-hover table-striped table-responsive view_table_cus">
                    <?php 
                        $id=$_GET['v'];
                        $selu="SELECT * FROM user_list NATURAL JOIN user_role WHERE user_id=$id";
                        $QU=mysqli_query($con,$selu);
                        $row=mysqli_fetch_assoc($QU) ?>
                     
                   <tr>
                        <td>Image</td>
                        <td>:</td>
                        <td> <?php 
                            if($row['user_photo']!=''){ ?>
                                <img src="uploads/<?=$row['user_photo']?>" height="100">
                           <?php }else{ ?>
                                <img src="uploads/default.png" height="100">
                          <?php  } ?></td>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td>:</td>
                        <td><?=$row['user_name']?></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>:</td>
                        <td><?=$row['user_email']?></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td>:</td>
                        <td><?=$row['user_phone']?></td>
                    </tr>
                    <tr>
                        <td>User Role</td>
                        <td>:</td>
                        <td><?=$row['role_name']?></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-2">
            </div>
        </div>
        <div class="panel-footer">
            <div class="col-md-4">
                <a href="#" class="btn btn-sm btn-primary">PDF</a>
                <a href="#" class="btn btn-sm btn-success">PRINT</a>
            </div>
            <div class="col-md-4">
            </div>
            <div class="col-md-4 text-right">
                
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    </div><!--col-md-12 end-->
    <?php
    get_footer();
    ?>