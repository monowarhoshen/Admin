<?php
ob_start();
require_once("functions/function.php");
NeedLogged();
get_header();
get_sidebar();
get_breadcam();
?>


<div class="col-md-12">
    <form action="" method="post">
    	<div class="col-md-6"><h2 style="margin: 0; float: right;">Are You  Sure Want To</h2></div>
    	<div class="col-md-6">
            <button name="delete-btn" class="btn btn-sm btn-danger">Delete</button>
          </div>
    </form>
</div>
    <?php
     if(isset($_POST['delete-btn'])){
      $id =$_GET['d'];
      $deletesql = "DELETE FROM user_list WHERE user_id=$id";
      if (mysqli_query($con, $deletesql)) {
      header("Location: user-data.php");
      exit();
    }
    }
    get_footer();
    ?>