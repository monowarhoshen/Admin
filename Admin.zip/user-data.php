<?php
ob_start();
require_once("functions/function.php");
NeedLogged();
get_header();
get_sidebar();
get_breadcam();
if ($_SESSION['role']==1) {
?>
<div class="col-md-12">
	<div class="panel panel-primary">
		<div class="panel-heading">
			<div class="col-md-5 heading_title">
				All Users Information
			</div>
			<div class="col-md-5">
				<form method="POST" action="user-search.php" class="navbar-form navbar-right" role="search">
					<div class="form-group">
						<input type="text" class="form-control" name="search" placeholder="Search">
					</div>
					<button type="submit" class="btn btn-default">Submit</button>
				</form>
			</div>
			<div class="col-md-2 text-right">
				<a href="user-form.php" class="btn btn-sm btn btn-primary"><i class="fa fa-plus-circle"></i> Add User</a>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="panel-body">
			<table class="table table-responsive table-striped table-hover table_cus">
				<thead class="table_head">
					<h2>Sir Pagination Use koresi ei page e</h2>
					<tr>
						<th>Name</th>
						<th>User Name</th>
						<th>Email</th>
						<th>Phone</th>
						<th>Image</th>
						<th>Role Name</th>
						<th>Reg. Time</th>
						<th>Manage</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$page=isset($_GET['p']) ? $_GET['p'] : null;
						if($page=='' && $page='1'){
							$page1=0;
						}else{
							$page1=($page*5)-5;
						}
						
						$sel="SELECT * FROM user_list NATURAL JOIN user_role ORDER BY user_id DESC  LIMIT $page1,5";
						if($Q=mysqli_query($con,$sel)){
					while($row=mysqli_fetch_assoc($Q)){ ?>
					
					<tr>
						<td><?=$row['user_name'];?></td>
						<td><?=$row['user_username'];?></td>
						<td><?=$row['user_email'];?></td>
						<td><?=$row['user_phone'];?></td>
						<td>
							<?php if ($row['user_photo']=="") {?>
							<img src="uploads/default.png" height="50">
							<?php }else{?>
							<img src="uploads/<?=$row['user_photo']?>" height="50">
							<?php } ?>
						</td>
						<td><?=$row['role_name'];?></td>
						<td><?=$row['user_time'];?></td>
						<td>
							<a href="user-view.php?v=<?=$row['user_id']?>"><i class="fa fa-plus-square fa-lg"></i></a>
							<a href="user-edit.php?name=<?=$row['user_name']?>&username=<?=$row['user_username']?>&email=<?=$row['user_email']?>&phone=<?=$row['user_phone']?>&pic=<?=$row['user_photo']?>&id=<?=$row['user_id']?>"><i class="fa fa-pencil-square fa-lg"></i></a>
							<a href="user-dlt.php?d=<?=$row['user_id']?>"><i class="fa fa-trash fa-lg"></i></a>
						</td>
					</tr>
				</tbody>
				<tfoot>
					<?php }	}
					
					$rsel="SELECT * FROM user_list";
					$QR=mysqli_query($con,$rsel);
					$cou=mysqli_num_rows($QR);
					
					$a=$cou/5;
					$a=ceil($a);
					echo "<br/>" . "<br/>";
					for($b=1;$b<=$a;$b++){	?>
				</tfoot>
			</table>
			<div class="col-md-2">
				<nav aria-label="Page navigation" style="float: left;">
					<ul class="pagination pagina_cus">
						<li ><a href="user-data.php?p=<?=$b;?>"><?=$b."";?></a>
						<?php }
					?></li>
				</ul>
			</nav>
		</div>
	</div>
</div>
</div><!--col-md-12 end-->
<?php
}else{
echo "You have no permission to view this page";
}
get_footer();
?>