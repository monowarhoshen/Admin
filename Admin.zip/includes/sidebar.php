<?php
require_once("functions/function.php");
 ?>
<div class="container-fluid content_full">
        <div class="row">
            <div class="col-md-2 sidebar pd0">
                <h2>MAIN NAVIGATION</h2>
                <ul>
                    <li><a href="menu.php"><i class="fa fa-user-circle"></i>Add Menu</a></li>
                    <li><a href="banner.php"><i class="fa fa-image"></i> Notice Board</a></li>
                    <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                </ul>
            </div><!--sidebar end-->