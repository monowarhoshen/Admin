<?php
require_once("functions/function.php");
NeedLogged();
get_header();
get_sidebar();
get_breadcam();

if (!empty($_POST)) {
    
    $name=$_POST['name'];
    $user=$_POST['username'];
    $email=$_POST['email'];
    $pass=$_POST['pass'];
    $phone=$_POST['phone'];
    $role=$_POST['role'];
    $pic=$_FILES['pic'];
      if($pic['name']!=""){
        $picname="user-".time().rand(100000,1000000).rand(10000,999999)."-".pathinfo($pic['name'],PATHINFO_EXTENSION);
      }else{
        $picname="";
      }
    

    if (!empty($name)) {
      $insert="INSERT INTO user_list(user_name,user_username,user_email,user_phone,user_pass,user_photo,user_time,role_id) VALUES('$name','$user','$email','$phone','$pass','$picname',NOW(),'$role')";
      if(mysqli_query($con,$insert)){
            move_uploaded_file($pic['tmp_name'],'uploads/'.$picname);
        echo "<script>alert('Data Submitted Successfully')</script>";
      }else{
        echo "<script>alert('Data Not Submit')</script>";
      }

    }else{
      echo "<script>alert('Enter Your Name')</script>";
    }
  }
?>

                <div class="col-md-12">
                	<form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                	<div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="col-md-9 heading_title">
                                Add Information
                             </div>
                             <div class="col-md-3 text-right">
                             	<a href="user-data.php" class="btn btn-sm btn btn-primary"><i class="fa fa-th"></i> All User List</a>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                      <div class="panel-body">
                          <div class="form-group">
                            <label for="" class="col-sm-3 control-label">Name</label>
                            <div class="col-sm-8">
                              <input type="text" class="form-control" placeholder="Enter Your Name" name="name"> 
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="" class="col-sm-3 control-label">User Name</label>
                            <div class="col-sm-8">
                              <input type="text" class="form-control" placeholder="Enter Your User Name" name="username"> 
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="" class="col-sm-3 control-label">Email</label>
                            <div class="col-sm-8">
                              <input type="email" class="form-control" placeholder="Enter Your Email" name="email">
                            </div>
                          </div>

                          <div class="form-group">
                            <label for="" class="col-sm-3 control-label">Phone</label>
                            <div class="col-sm-8">
                              <input type="number" class="form-control" placeholder="Enter Your Phone Number" name="phone"> 
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="" class="col-sm-3 control-label">Password</label>
                            <div class="col-sm-8">
                              <input type="password" class="form-control" placeholder="Enter Your Password" name="pass">
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="" class="col-sm-3 control-label">Select Role</label>
                            <div class="col-sm-4">
                              <select class="form-control select_cus" name="role">
                                  <option value="">Slect User Role</option>
                                    <?php 
                                      $sr="SELECT * FROM user_role";
                                      $qr=mysqli_query($con,$sr);
                                      while ($rd=mysqli_fetch_assoc($qr)) { ?>

                                        <option value="<?=$rd['role_id']?>"><?=$rd['role_name']?></option>
                                      <?php }
                                     ?>
                              </select>
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="" class="col-sm-3 control-label">Upload</label>
                            <div class="col-sm-8">
                              <input type="file" name="pic">
                            </div>
                          </div>
                      </div>
                      <div class="panel-footer text-center">
                        <button class="btn btn-sm btn-primary">REGISTRATION</button>
                      </div>
                    </div>
                    </form>
                </div><!--col-md-12 end-->
        <?php
    get_footer();
    ?>