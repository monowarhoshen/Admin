<?php session_start();
	require_once("../config.php");
	function get_header(){
		require_once("includes/header.php");
	}

	function get_sidebar(){
		require_once("includes/sidebar.php");
	}

	function get_breadcam(){
		require_once("includes/breadcam.php");
	}

	function get_footer(){
		require_once("includes/footer.php");
	}

	function GetLogged(){
		return !empty($_SESSION['user']) ? true:false;
	}
	function NeedLogged(){
		$checkLog=GetLogged();
			if (!$checkLog) {
				header("Location: user-login.php");
			}
		
	}

 ?>